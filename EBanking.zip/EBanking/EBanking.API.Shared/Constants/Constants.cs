﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBanking.API.Shared.Constants
{
    public class Constants
    {

       public static Guid RowStatusUid = new Guid("17D0EC91-B203-4E94-99D3-80A77E2C61EA");


    }
}
