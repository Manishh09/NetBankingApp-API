﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefAndOutDemo
{
    public class OutKeywordDemo
    {
        public static void Check(List<string> names)
        {
            foreach (var item in names)
            {
                int index;
                GetIndex(out index, names);
                Console.WriteLine(index.ToString() + "-" + item);
            }
        }
        public static void GetIndex(out int index, List<string> names)
        {
            index = IndexHelper.GetLastIndex(names);
        }
    }
    public static class IndexHelper
    {
        public static int GetLastIndex(List<string> names)
        {
            return names.LastIndexOf(names[names.Count - 1]);
        }
    }
}
