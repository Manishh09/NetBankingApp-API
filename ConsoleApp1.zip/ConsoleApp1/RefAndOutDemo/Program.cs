﻿using System;
using System.Collections.Generic;
using OverridingEqualsMethodDemo;
namespace RefAndOutDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            List<string> names = new List<string> { "ab", "cd", "ef", "gh" };
            // RefKeywordDemo.Check(names);
            //OutKeywordDemo.Check(names);

            //Employee e1 = new Employee();
            //e1.Id = 1;
            //e1.Name = "manish";

            //Employee e2 = e1;

            //Console.WriteLine(e1 == e2);// True becasue of the reference equality as e1 and e2 objects reference variables pointing the same object
            //Console.WriteLine(e1.Equals(e2));// True because equals checks the value equality

            //Employee e3 = new Employee();
            //e3.Id = 1;
            //e3.Name = "manish";

            //Console.WriteLine(e1 == e3);//False beacause e1 and e2 are two different objects though the values are same
            //Console.WriteLine(e1.Equals(e3));// Should have been true but returns false so we need to override this equals method in this case

            string[] @for = { "John", "James", "Joan", "Jamie" };
            for (int ctr = 0; ctr < @for.Length; ctr++)
            {
                Console.WriteLine($"Here is your gift, {@for[ctr]}!");
            }

        }
      
    }


}
