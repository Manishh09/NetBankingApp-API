﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RefAndOutDemo
{
    public class RefKeywordDemo
    {
        public static void Check(List<string> names)
        {
            foreach (var item in names)
            {
                int index = 0;
                IncrementIndex(ref index);
                Console.WriteLine(index.ToString() + "-" + item);
            }
        }
        public static void IncrementIndex(ref int index2)
        {
            index2++;
        }
    }

    //index and index2 are pointing to same memory location and change in one impacts other
}
