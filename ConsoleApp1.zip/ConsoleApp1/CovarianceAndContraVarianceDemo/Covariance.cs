﻿using System;
using System.Collections.Generic;

namespace CovarianceAndContraVarianceDemo
{
    class Covarianace
    {
        static void Main(string[] args)
        {
            Parent obj = new Child();
            obj = new Child2();

            IEnumerable<Parent> objnew = new List<Child>();
        }
    }
}
