﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CovarianceAndContraVarianceDemo
{
    public class Parent
    {
    }
    class Child : Parent
    {

    }
    class Child2 : Parent
    {

    }
}
