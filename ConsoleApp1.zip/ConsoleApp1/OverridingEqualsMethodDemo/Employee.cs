﻿using System;

namespace OverridingEqualsMethodDemo
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }

        public override bool Equals(object obj)
        {
            if (obj is null) return false;
            if (!(obj is Employee)) return false;
            return this.Id == ((Employee)obj).Id && this.Name == ((Employee)obj).Name;
        }
        public override int GetHashCode()
        {
            return Id.GetHashCode() ^ Name.GetHashCode();
        }
    }
}
