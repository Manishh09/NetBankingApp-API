﻿using System;

namespace ConsoleApp1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            bool isTrue1 = HelperClass.IsValid(1, 2);
            if (isTrue1)
                Console.WriteLine("Yes");
            else Console.WriteLine("No");

            //Generics
            //bool isTrue2 = HelperClass.IsValid<int>(1, 2);
            //if (isTrue2)
            //    Console.WriteLine("Yes");
            //else Console.WriteLine("No");


            GenericClass<int> obj = new GenericClass<int>(20);
            Console.WriteLine("Output generic member vlaue: {0}", obj.genericMethod(10));
        }
    }
}
