﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class HelperClass
    {
        public static bool IsValid(int a, int b)
        {
            return a == b;
        }

        //public static bool IsValid(string a, string b)
        //{
        //    return a == b;
        //}
        //public static bool IsValid(long a, long b)
        //{
        //    return a == b;
        //}
        //public static bool IsValid(double a, double b)
        //{
        //    return a == b;
        //}


        #region Generics -Beginning
        //Using the Object Type
        //public static bool IsValid(object a, object b) //boxing and un-boxing comes into the picture while converting object type into the value type...=> performance
        //{
        //    return a == b;
        //}

        //Generics
        //public static bool isvalid<t>(t a, t b)
        //{
        //    return a.Equals(b);
        //}

        //Note: At compilation time, these angular brackets are going to be replaced with some specific data types.
        #endregion

       
    }
    #region Generics with Class and its memebers
    public class GenericClass<T>
    {
        private T genericVariable;
        public GenericClass(T somevalue)
        {
            genericVariable = somevalue;
        }

        public T genericMethod(T genParamter)
        {
            Console.WriteLine("Output Value: {0}", genParamter);

            return genericVariable;
        }
    }

    #endregion

}

