using generics.linq;
using generics.adonet;
using generics.EntityFrameworkCore.trialtwocontextreplica;
using generics.EntityFrameworkCore;
namespace generics{
    public class testbed{
        public static void Main(string[] args){
            // linqTial obj=new linqTial();
            // obj.main();
            //linqSample.main();
            // adonet.adonet.main();
             
             //AdoNetConnectedExamples.main();
            // AdoNetConnectedExamples.main();
            // adonetsample.main();
            // TrialTwoContextReplicaConsumer.main();
           //IOCCOntainerConsumer.main();
           trialtwocontextconsumer.main();
           
        }
    }
}