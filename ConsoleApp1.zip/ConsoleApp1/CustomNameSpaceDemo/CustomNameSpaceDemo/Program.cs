﻿using System;

namespace CustomNameSpaceDemo
{

    class classA
    {
        public void A()
        {
            Console.WriteLine("inside the CustomNameSpaceDemo");
        }
    }
    namespace NestedNameSpace
    {
        class classB
        {
            public void A()
            {
                Console.WriteLine("inside the NestedNameSpace");
            } 
            
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Inside Program Class");
            //classA obj = new classA();
            //obj.A();
            new classA().A();
            new CustomNameSpaceDemo.classA().A();
            new NestedNameSpace.classB().A();
            

        }
    }

   
}
