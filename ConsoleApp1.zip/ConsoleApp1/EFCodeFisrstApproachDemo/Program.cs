﻿using System;

namespace EFCodeFisrstApproachDemo
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }

   
}
