﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EFCodeFisrstApproachDemo
{
    public class student
    {
       
        public int studentId { get; set; }     
            
        public string Name { get; set; }

         public int StudentDetailsId { get; set; } 

         public studentDetails studentdetails { get; set; }    
    }

    public class studentDetails
    {
       
        public int StudentDetailsId { get; set; }     
            
        public string Address { get; set; }

        public student student { get; set; }
    }

    public class departmetnt
    {
       
        public int deptartmentId { get; set; }     
            
        public string Name { get; set; }

        public student student { get; set; }
    }

    public class studentDepartmetntAssociation
    {
       
        public int Id { get; set; }     
            
        public student studentId { get; set; }

        public departmetnt deptartmentId { get; set; }  

        public student students{ get; set; }

         public departmetnt departmetnts{ get; set; }
    }
}
