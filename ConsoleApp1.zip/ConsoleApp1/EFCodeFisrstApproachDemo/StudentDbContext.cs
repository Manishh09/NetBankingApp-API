﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using Microsoft.EntityFrameworkCore;



namespace EFCodeFisrstApproachDemo
{
    public class StudentDbContext : DbContext
    {

       DbSet<student> Students { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder builder)
        {
            if(!builder.IsConfigured)
            builder.UseSqlServer("Data Source=HDC3-D-J0RTXJ2\\SQLEXPRESS;Initial Catalog=SampleDB;Integrated Security=true");
        }

        protected override void OnModelCreating(ModelBuilder builder){

            builder.Entity<student>(x=>{
                x.Property(y=>y.studentId)
                .UseSqlServerIdentityColumn(1,1);
                x.Property(y=>y.Name).HasColumnType("navvarchar(100)");
                x.HasKey(y=>y.studentId);
                x.HasOne(y=>y.studentdetails)
                .WithOne(y=>y.student)
                .HasForeignKey<student>(y=>y.StudentDetailsId)
                .HasConstraintName("FK_studentDetailsId_student");
            });

            builder.Entity<studentDetails>(x=>{
                x.Property(y=>y.StudentDetailsId)
                .UseSqlServerIdentityColumn(1,1);
                x.Property(y=>y.Address)
                .HasMaxLength(500);
                x.HasKey(y=>y.StudentDetailsId);
               
            });    

              builder.Entity<departmetnt>(x=>{
                  x.Property(y=>y.deptartmentId)
                  .UseSqlServerIdentityColumn(1,1);

                  x.Property(x=>x.Name).HasColumnType("nvarchar(100)");

              }) ;

              builder.Entity<studentDepartmetntAssociation>(x=>{

                  x.Property(y=>y.Id).UseSqlServerIdentityColumn(1,1);
                  


              });



        }
        
    }
}
