﻿using System;

namespace InheritanceAndPolymorphismDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Mytutorial tut = new Mytutorial();
            tut.SetName("C#.NET");
            tut.RenameTut("C#");
            Console.WriteLine(tut.GetName());
        }
    }
}
