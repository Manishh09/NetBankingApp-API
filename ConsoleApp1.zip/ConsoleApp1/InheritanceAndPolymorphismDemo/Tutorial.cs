﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceAndPolymorphismDemo
{
    public class Tutorial
    {
        protected int id;
        protected string name;

        public void SetName(string tName)
        {
         
            name = tName;
        }
        public string GetName()
        {

            return name;
        }
    }

    public class Mytutorial : Tutorial
    {
        public void RenameTut(string tname)
        {
            name = tname;
        }
    }
}
