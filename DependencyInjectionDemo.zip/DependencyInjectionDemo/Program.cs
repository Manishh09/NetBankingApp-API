﻿using System;
using System.Collections.Generic;

namespace DependencyInjectionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeBL empBL = new EmployeeBL(new EmployeeDAL());

            List<Employee> lstEmployee= empBL.GetAllEmployees();

            foreach (var item in lstEmployee)
            {
                Console.WriteLine("ID={0}, Name={1},Department={2}", item.ID, item.Name, item.Department);
            }
            Console.ReadKey();
            
           
        }
    }
}
