﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DependencyInjectionDemo
{
    public interface IEmployeeDAL
    {
        public List<Employee> SelectAllEmployees();
    }
}
