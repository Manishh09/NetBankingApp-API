﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DependencyInjectionDemo
{
    public class EmployeeBL
    {
        public IEmployeeDAL _empDAL;
        //public EmployeeDAL _empDAL;

        public EmployeeBL(IEmployeeDAL empDAL)
        {
            _empDAL = empDAL;
        }
        public List<Employee> GetAllEmployees()
        {
            _empDAL = new EmployeeDAL();

            return _empDAL.SelectAllEmployees();
        }
    }
}
