﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DependencyInjectionDemo
{
    public class EmployeeDAL : IEmployeeDAL
    {
        public List<Employee> SelectAllEmployees()
        {
            List<Employee> ListEmployees = new List<Employee>();
            ListEmployees.Add(new Employee() { ID = 1, Name = "Manish", Department = "IT" });
            ListEmployees.Add(new Employee() { ID = 2, Name = "Will", Department = "HR" });
            ListEmployees.Add(new Employee() { ID = 3, Name = "Jack", Department = "Payroll" });
            
            return ListEmployees;
        }

    }
}
