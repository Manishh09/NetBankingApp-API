﻿using System;

namespace EBanking.API.Shared
{
    public class Class1
    {
    }
}
