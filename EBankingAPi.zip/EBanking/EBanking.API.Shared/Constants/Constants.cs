﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EBanking.API.Shared.Constants
{
    public class Constants
    {

       public static Guid RowStatusUid = new Guid("");


    }
}
