﻿using System;

namespace EBanking.API.Models
{
    public class Class1
    {
    }
}
