﻿using EBanking.API.BusinessDomain.Interface;
using EBanking.API.Infrastructure;
using EBanking.API.Models;
using EBanking.API.Models.DomainModels;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using EBanking.API.Shared.Constants;
using System;

namespace EBanking.API.BusinessDomain.Concrete
{
    public class CustomerConcrete : ICustomer
    {
        EBankingUnitOfWork _eBankingUnitOfWork;
        public CustomerConcrete(EBankingUnitOfWork eBankingUnitOfWork)
        {
            _eBankingUnitOfWork = eBankingUnitOfWork;
        }

        public async Task<List<CustomerViewModel>> GetDetails()
        {
            List<CustomerViewModel> response = new List<CustomerViewModel>();
            response = (from cd in _eBankingUnitOfWork.CustomerRepo.GetAll()
                        select new CustomerViewModel
                        {
                            CustomerId = cd.CustomerId,
                            CustomerUid = cd.CustomerUid,
                            EmailId = cd.EmailId,
                            Password = cd.Password
                            
                        }).ToList();
                        
            return response;
        }

        public bool SaveCustomerDetails(CustomerViewModel cust)
        {
            var savecust = _eBankingUnitOfWork.CustomerRepo.Get(x => x.RowStatusUid.Equals(Constants.RowStatusUid)).FirstOrDefault();

            savecust.EmailId = cust.EmailId;
            savecust.Password = cust.Password;
            savecust.CreatedOn = cust.CreatedOn;
            savecust.CreatedBy = cust.CreatedBy;
            savecust.ModifiedBy = cust.ModifiedBy;
            savecust.ModifiedOn = cust.ModifiedOn;
            return _eBankingUnitOfWork.SaveChanges();

        }

        public bool ValidEmailId(string emailId)
        {
            bool uniqueEmailId = false;
            var IsTrue = _eBankingUnitOfWork.CustomerRepo.Get(x => x.EmailId == emailId).Count() > 0;
            if (!IsTrue)
                  uniqueEmailId = false;           
            else
                uniqueEmailId = true;
            
            return uniqueEmailId;
        }

    }
}
